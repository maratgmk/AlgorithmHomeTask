import java.util.Scanner;

/*Дано натуральное число N. Выведите слово YES, если число N является точной степенью двойки,
 или слово NO в противном случае. Операцией возведения в степень пользоваться нельзя!
        Ввод 8
        Вывод Yes
        Ввод 3
        Вывод No */
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int input = scanner.nextInt();
        if (isPowerOfTwo(input)) {
            System.out.println("YES");
        } else {
            System.out.println("NO");
        }

        System.out.println(input % 2);
        System.out.println(input / 2);


    }


    public static boolean isPowerOfTwo(int n) {
        if (n == 1) {
            return true;
        } else if (n % 2 == 0 && n != 0) {
            return isPowerOfTwo(n / 2);
        } else {
            return false;
        }
    }


}