/*
Напишите рекурсивный метод, который выводит на экран числа Фибоначчи до N-ого элемента.
 */

import java.util.Scanner;

public class Task3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        printFibonacci(n);

    }

    public static void printFibonacci(int n) {
        if (n < 1) { // базовый случай: если N меньше 1, ничего не выводим
            return;
        } else if (n == 1) { // базовый случай: если N равно 1, выводим первое число Фибоначчи
            System.out.print("0 ");
        } else if (n == 2) { // базовый случай: если N равно 2, выводим первые два числа Фибоначчи
            System.out.print("0 1 ");
        } else { // рекурсивный случай: выводим следующее число Фибоначчи и рекурсивно вызываем этот же метод для следующего числа
            printFibonacci(n - 1); // рекурсивный вызов для предыдущего числа
            int fib = fibonacci(n - 1); // вычисляем текущее число Фибоначчи
            System.out.print(fib + " ");
        }
    }

    public static int fibonacci(int n) {
        if (n < 2) { // базовый случай: первые два числа Фибоначчи - 0 и 1
            return n;
        } else { // рекурсивный случай: вычисляем число Фибоначчи, складывая два предыдущих числа
            return fibonacci(n - 1) + fibonacci(n - 2);
        }
    }
}
